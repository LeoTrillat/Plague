package model;

import java.util.ArrayList;
import javafx.beans.property.SimpleLongProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.scene.image.Image;
import javafx.scene.input.MouseEvent;

public class Monde {

	private Image monde;
	private SimpleStringProperty urlPays;
	private ArrayList<Pays> listePays;
	private SimpleLongProperty nombreVivants = new SimpleLongProperty (7550262000L);
	private SimpleLongProperty nombreMorts = new SimpleLongProperty (0);
	private ArrayList<Proximite> listeProximite;
	
	public Monde (){
		
		this.listeProximite = new ArrayList<Proximite>();
		this.urlPays = new SimpleStringProperty();
		this.monde = new Image("/images/terre.png");
		listePays = new ArrayList<Pays>();
		
	}
	
	public SimpleLongProperty getNombreHumains() {
		return this.nombreVivants;
	}
	
	public SimpleLongProperty getNombreMorts() {
		return this.nombreMorts;
	}
	
	public SimpleStringProperty getInfosPays(MouseEvent e){
		
		SimpleStringProperty url = new SimpleStringProperty();
		
		// On prend le code couleur du pays sur lequel on clique
		urlPays.setValue(monde.getPixelReader().getColor((int)e.getX(),(int)e.getY()).toString());
		
		// On fait une boucle pour comparer le code couleur des pays et le code couleur reçu
		for (int i = 0; i < listePays.size(); i++){
			
			url.setValue(listePays.get(i).getUrl()); // Prend le code couleur du pays de la liste à l'indice i

			if (url.getValue().equals(urlPays.getValue())) { 
				
				urlPays.setValue(listePays.get(i).getNom() + " :\nClimat : " + listePays.get(i).getClimat() + "\nDensité : "
						+ listePays.get(i).getDensite() + "\nTempérature : " + listePays.get(i).getTemperature() + "\nRichesse : "
						+ listePays.get(i).getRichesse());
				return urlPays;
			} 
		}
		urlPays.setValue("Océan");
		return urlPays;
	}
	
	public String getPays(MouseEvent e) {
		
		String url = new String();
		String urlPays = new String();
		
		// On prend le code couleur du pays sur lequel on clique
		urlPays = monde.getPixelReader().getColor((int)e.getX(),(int)e.getY()).toString();
		
		// On fait une boucle pour comparer le code couleur des pays et le code couleur reçu
		for (int i = 0; i < listePays.size(); i++){
			
			url = listePays.get(i).getUrl(); // Prend le code couleur du pays de la liste à l'indice i
			
			if (url.equals(urlPays)) { 
				
				return listePays.get(i).getNom();
			}
		}
		return "Océan";
	}
	
	public String getPaysAProximite(String pays) {
		
		for (int i = 0; i < listeProximite.size(); i++) {
			
			if (pays.equals(listeProximite.get(i).getNomPays())) {
				
				return listeProximite.get(i).toString();
			}
		}
		return "Océan";
	}
	
	public void créerListePays() {
		
		listePays.add(new Pays("Afghanistan",0,2,2,1,"0xcc4a85ff"));
		listePays.add(new Pays("Afrique Centrale",0,0,1,2,"0xb9ccb5ff"));
		listePays.add(new Pays("Afrique de l'Est",0,0,1,2,"0x5d0980ff"));
		listePays.add(new Pays("Afrique du Sud",2,2,1,1,"0xa7aaadff"));
		listePays.add(new Pays("Afrique de l'Ouest",0,0,1,2,"0x73b526ff"));
		listePays.add(new Pays("Algérie",0,2,1,1,"0xd17448ff"));
		listePays.add(new Pays("Allemagne",1,1,0,0,"0x66684aff"));
		listePays.add(new Pays("Amérique Centrale",0,0,1,2,"0xbbdc90ff"));
		listePays.add(new Pays("Angola",0,2,1,2,"0xfafbc9ff"));
		listePays.add(new Pays("Arabie Saoudite",2,2,1,1,"0x9a6128ff"));
		listePays.add(new Pays("Argentine",2,0,2,2,"0xd9ac58ff"));
		listePays.add(new Pays("Asie Centrale",0,2,2,1,"0x3ee90fff"));
		listePays.add(new Pays("Asie du Sud Est",0,0,1,0,"0x664fa6ff"));
		listePays.add(new Pays("Australie",1,1,1,1,"0x1c91deff"));
		listePays.add(new Pays("Balkans",2,0,0,0,"0x18c40dff"));
		listePays.add(new Pays("Baltiques",2,0,0,0,"0x97d595ff"));
		listePays.add(new Pays("Bolivie",0,0,2,0,"0xc42b88ff"));
		listePays.add(new Pays("Botswana",0,2,1,2,"0x4ef234ff"));
		listePays.add(new Pays("Brésil",2,0,1,0,"0x34b637ff"));
		listePays.add(new Pays("Canada",1,2,0,2,"0xb25381ff"));
		listePays.add(new Pays("Caraïbes",0,0,1,0,"0x3a7590ff"));
		listePays.add(new Pays("Chine",2,1,2,2,"0x757822ff"));
		listePays.add(new Pays("Colombie",0,0,2,1,"0x772788ff"));
		listePays.add(new Pays("Corée",2,1,2,2,"0x2afa2fff"));
		listePays.add(new Pays("Egypte",0,2,1,1,"0xe4b04cff"));
		listePays.add(new Pays("Europe Centrale",1,2,0,0,"0x0c3a6eff"));
		listePays.add(new Pays("Espagne",1,2,1,1,"0xbc0fcdff"));
		listePays.add(new Pays("Etats-Unis",1,1,2,2,"0xd0f42eff"));
		listePays.add(new Pays("Finlande",1,0,0,0,"0xc53929ff"));
		listePays.add(new Pays("France",1,1,2,2,"0x3e4bcfff"));
		listePays.add(new Pays("Groenland",2,0,0,2,"0xffffffff"));
		listePays.add(new Pays("Islande",1,2,0,2,"0x509957ff"));
		listePays.add(new Pays("Inde",2,0,1,0,"0xd3ecdeff"));
		listePays.add(new Pays("Indonésie",2,0,1,0,"0xef6d16ff"));
		listePays.add(new Pays("Iran",2,2,1,1,"0x37bd8dff"));
		listePays.add(new Pays("Irak",2,2,1,1,"0x5c0d41ff"));
		listePays.add(new Pays("Italie",1,1,2,2,"0xa03505ff"));
		listePays.add(new Pays("Japon",1,1,2,2,"0xfa25e6ff"));
		listePays.add(new Pays("Kazakhstan",0,2,2,1,"0x065b69ff"));
		listePays.add(new Pays("Libye",2,1,1,1,"0xbe1c85ff"));
		listePays.add(new Pays("Madagascar",0,0,2,2,"0x35e677ff"));
		listePays.add(new Pays("Maroc",0,0,1,1,"0x596925ff"));
		listePays.add(new Pays("Mexique",2,1,1,1,"0x5d06aaff"));
		listePays.add(new Pays("Moyen Orient",2,2,1,1,"0x1a8b08ff"));
		listePays.add(new Pays("Norvège",1,1,0,0,"0x6d3bedff"));
		listePays.add(new Pays("Nouvelle Guinée",0,2,1,0,"0xb72887ff"));
		listePays.add(new Pays("Nouvelle Zélande",1,1,2,2,"0x88b094ff"));
		listePays.add(new Pays("Pakistan",0,2,1,1,"0x0366e0ff"));
		listePays.add(new Pays("Pérou",0,0,0,1,"0x118935ff"));
		listePays.add(new Pays("Philippines",0,2,1,0,"0x21a63dff"));
		listePays.add(new Pays("Pologne",2,0,0,0,"0x630768ff"));
		listePays.add(new Pays("Russie",2,0,0,0,"0xd5f861ff"));
		listePays.add(new Pays("Soudan",0,0,1,1,"0x82e2f2ff"));
		listePays.add(new Pays("Suède",1,1,0,0,"0x61b821ff"));
		listePays.add(new Pays("Turquie",2,0,2,2,"0x69090eff"));
		listePays.add(new Pays("Royaume-Uni",1,1,0,0,"0x7187a0ff"));
		listePays.add(new Pays("Ukraine",2,0,0,0,"0xcc6f09ff"));
		listePays.add(new Pays("Zimbabwe",0,2,1,2,"0xf4ef2cff"));
		
	}
	
	public void creerListeProximite() {
		
		listeProximite.add(new Proximite("Afghanistan","Iran","Asie Centrale","Pakistan", null, null, null, null, null));
		listeProximite.add(new Proximite("Afrique Centrale","Afrique de l'Ouest","Libye","Soudan","Afrique de l'Est","Angola", null, null, null));
		listeProximite.add(new Proximite("Afrique de l'Est","Afrique du Sud","Zimbabwe","Botswana","Angola","Afrique Centrale","Soudan", null, null));
		listeProximite.add(new Proximite("Afrique du Sud","Angola","Botswana","Zimbabwe","Afrique de l'Est", null, null, null, null));
		listeProximite.add(new Proximite("Afrique de l'Ouest","Maroc","Algérie","Libye","Afrique Centrale", null, null, null, null));
		listeProximite.add(new Proximite("Algérie","Libye","Afrique de l'Ouest","Maroc", null, null, null, null, null));
		listeProximite.add(new Proximite("Allemagne","Pologne","Europe Centrale","France", null, null, null, null, null));
		listeProximite.add(new Proximite("Amérique Centrale","Mexique","Colombie", null, null, null, null, null, null));
		listeProximite.add(new Proximite("Angola","Afrique Centrale","Afrique de l'Est","Botswana","Afrique du Sud", null, null, null, null));
		listeProximite.add(new Proximite("Arabie Saoudite","Egypte","Moyen Orient","Irak", null, null, null, null, null));
		listeProximite.add(new Proximite("Argentine","Pérou","Bolivie","Brésil", null, null, null, null, null));
		listeProximite.add(new Proximite("Asie Centrale","Kazakhstan","Chine","Pakistan","Afghanistan","Iran", null, null, null));
		listeProximite.add(new Proximite("Asie du Sud Est","Inde","Chine", null, null, null, null, null, null));
		listeProximite.add(new Proximite("Australie", null, null, null, null, null, null, null, null));
		listeProximite.add(new Proximite("Balkans","Italie","Europe Centrale","Turquie", null, null, null, null, null));
		listeProximite.add(new Proximite("Baltiques","Russie","Ukraine","Pologne", null, null, null, null, null));
		listeProximite.add(new Proximite("Bolivie","Pérou","Brésil","Argentine", null, null, null, null, null));
		listeProximite.add(new Proximite("Botswana","Angola","Afrique de l'Est","Zimbabwe","Afrique du Sud", null, null, null, null));
		listeProximite.add(new Proximite("Brésil","Argentine","Bolivie","Pérou","Colombie", null, null, null, null));
		listeProximite.add(new Proximite("Canada","Etats-Unis", null, null, null, null, null, null, null));
		listeProximite.add(new Proximite("Caraïbes", null, null, null, null, null, null, null, null));
		listeProximite.add(new Proximite("Chine","Asie du Sud Est","Inde","Pakistan","Asie Centrale","Kazakhstan","Russie","Corée", null));
		listeProximite.add(new Proximite("Colombie","Amérique Centrale","Brésil","Pérou", null, null, null, null, null));
		listeProximite.add(new Proximite("Corée","Chine", null, null, null, null, null, null, null));
		listeProximite.add(new Proximite("Egypte","Moyen Orient","Arabie Saoudite","Soudan","Libye", null, null, null, null));
		listeProximite.add(new Proximite("Europe Centrale","Allemagne","Pologne","Ukraine","Balkans","Italie","France", null, null));
		listeProximite.add(new Proximite("Espagne","France", null, null, null, null, null, null, null));
		listeProximite.add(new Proximite("Etats-Unis","Canada","Mexique", null, null, null, null, null, null));
		listeProximite.add(new Proximite("Finlande","Suède","Norvège","Russie", null, null, null, null, null));
		listeProximite.add(new Proximite("France","Espagne","Allemagne","Europe Centrale","Italie", null, null, null, null));
		listeProximite.add(new Proximite("Groenland", null, null, null, null, null, null, null, null));
		listeProximite.add(new Proximite("Islande", null, null, null, null, null, null, null, null));
		listeProximite.add(new Proximite("Inde","Pakistan","Chine","Asie du Sud Est", null, null, null, null, null));
		listeProximite.add(new Proximite("Indonésie", null, null, null, null, null, null, null, null));
		listeProximite.add(new Proximite("Iran","Irak","Russie","Asie Centrale","Afghanistan","Pakistan", null, null, null));
		listeProximite.add(new Proximite("Irak","Moyen Orient","Turquie","Iran","Arabie Saoudite", null, null, null, null));
		listeProximite.add(new Proximite("Italie","France","Europe Centrale","Balkans", null, null, null, null, null));
		listeProximite.add(new Proximite("Japon", null, null, null, null, null, null, null, null));
		listeProximite.add(new Proximite("Kazakhstan","Russie","Chine","Asie Centrale", null, null, null, null, null));
		listeProximite.add(new Proximite("Libye","Egypte","Soudan","Afrique Centrale","Afrique de l'Ouest","Algérie", null, null, null));
		listeProximite.add(new Proximite("Madagascar", null, null, null, null, null, null, null, null));
		listeProximite.add(new Proximite("Maroc","Algérie","Afrique de l'Ouest", null, null, null, null, null, null));
		listeProximite.add(new Proximite("Mexique","Etats-Unis","Amérique Centrale", null, null, null, null, null, null));
		listeProximite.add(new Proximite("Moyen Orient","Turquie","Irak","Arabie Saoudite","Egypte", null, null, null, null));
		listeProximite.add(new Proximite("Norvège","Suède","Finlande","Russie", null, null, null, null, null));
		listeProximite.add(new Proximite("Nouvelle Guinée", null, null, null, null, null, null, null, null));
		listeProximite.add(new Proximite("Nouvelle Zélande", null, null, null, null, null, null, null, null));
		listeProximite.add(new Proximite("Pakistan","Iran","Afghanistan","Asie Centrale","Chine","Inde", null, null, null));
		listeProximite.add(new Proximite("Pérou","Colombie","Brésil","Bolivie","Argentine", null, null, null, null));
		listeProximite.add(new Proximite("Philippines", null, null, null, null, null, null, null, null));
		listeProximite.add(new Proximite("Pologne","Baltiques","Ukraine","Europe Centrale","Allemagne", null, null, null, null));
		listeProximite.add(new Proximite("Russie","Chine","Kazakhstan","Iran","Turquie","Ukraine","Baltiques","Finlande","Norvège"));
		listeProximite.add(new Proximite("Soudan","Afrique de l'Est","Afrique Centrale","Libye","Egypte", null, null, null, null));
		listeProximite.add(new Proximite("Suède","Norvège","Finlande", null, null, null, null, null, null));
		listeProximite.add(new Proximite("Turquie","Balkans","Russie","Iran","Irak","Moyen Orient", null, null, null));
		listeProximite.add(new Proximite("Royaume-Uni", null, null, null, null, null, null, null, null));
		listeProximite.add(new Proximite("Ukraine","Europe Centrale","Pologne","Baltiques","Russie", null, null, null, null));
		listeProximite.add(new Proximite("Zimbabwe","Afrique du Sud","Botswana","Afrique de l'Est", null, null, null, null, null));
	}
}
