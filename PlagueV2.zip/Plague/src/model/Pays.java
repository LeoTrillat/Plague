package model;

public class Pays {
	
	private String nom;
	private int richesse;
	private int densite;
	private int temperature;
	private int climat;
	private String codeCouleur;
	
	public Pays (String nom, int richesse, int densite, int temperature, int climat, String codeCouleur){
		this.nom = nom;
		this.richesse = richesse;
		this.densite = densite;
		this.temperature = temperature;
		this.climat = climat;
		this.codeCouleur = codeCouleur;
	}
	
	public String getUrl() {
		return this.codeCouleur;
	}
	
	public String getNom() {
		return this.nom;
	}
	
	public String getRichesse() {
		
		if (this.richesse == 0) {
			return "Pauvre";
		} else if (this.richesse == 1) {
			return "Riche";
		} else {
			return "Moyen";
		}	
	}
	
	public String getDensite() {
		
		if (this.densite == 0) {
			return "Rural";
		} else if (this.densite == 1) {
			return "Urbain";
		} else {
			return "Moyen";
		}	
	}
	
	public String getTemperature() {
		
		if (this.temperature == 0) {
			return "Froid";
		} else if (this.temperature == 1) {
			return "Chaud";
		} else {
			return "Moyen";
		}	
	}
	
	public String getClimat() {
		
		if (this.climat == 0) {
			return "Humide";
		} else if (this.climat == 1) {
			return "Aride";
		} else {
			return "Moyen";
		}	
	}
}
