package model;

import java.util.ArrayList;

public class Proximite {
	
	private String nomPays = new String();
	private String prox1 = new String();
	private String prox2 = new String();
	private String prox3 = new String();
	private String prox4 = new String();
	private String prox5 = new String();
	private String prox6 = new String();
	private String prox7 = new String();
	private String prox8 = new String();

	public Proximite (String nomPays, String prox1, String prox2, String prox3, String prox4, String prox5, String prox6, String prox7, String prox8) {
		
		this.nomPays = nomPays;
		this.prox1 = prox1;
		this.prox2 = prox2;
		this.prox3 = prox3;
		this.prox4 = prox4;
		this.prox5 = prox5;
		this.prox6 = prox6;
		this.prox7 = prox7;
		this.prox8 = prox8;
		
	}
	
	public String getNomPays() {
		return this.nomPays;
	}
	
	public String toString() {
		if (prox1 == null) {
			return "Aucune proximité";
		} else if (prox2 == null) {
			return prox1;
		} else if (prox3 == null) {
			return prox1 + prox2;
		} else if (prox4 == null) {
			return prox1 + prox2 + prox3;
		} else if (prox5 == null) {
			return prox1 + prox2 + prox3 + prox4;
		} else if (prox6 == null) {
			return prox1 + prox2 + prox3 + prox4 + prox5;
		} else if (prox7 == null) {
			return prox1 + prox2 + prox3 + prox4 + prox5 + prox6;
		} else if (prox8 == null) {
			return prox1 + prox2 + prox3 + prox4 + prox5 + prox6 + prox7;
		} else {
			return prox1 + prox2 + prox3 + prox4 + prox5 + prox6 + prox7 + prox8;
		}
	}
}
