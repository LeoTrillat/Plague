package model;

import java.text.DateFormat;
import java.util.Calendar;
import java.util.Date;

import javafx.beans.property.SimpleStringProperty;

public class Jeu {

	private SimpleStringProperty dateString;
	private DateFormat dateFormat;
	private Date date;
	private int jour;
	
	public Jeu() {
		
		this.jour = 1;
		this.dateString = new SimpleStringProperty();
		this.dateFormat = DateFormat.getDateInstance(DateFormat.FULL);
		this.date = Calendar.getInstance().getTime();
		
	}
	
	// Retourne la date du jour et le numéro du jour
	
	public SimpleStringProperty getDate() {
		
		dateString.setValue(dateFormat.format(date).toString() + "\nJour " + this.jour);
		return dateString;
		
	}
	
	
}
