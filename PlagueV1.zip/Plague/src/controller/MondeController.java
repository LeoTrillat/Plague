package controller;

import javafx.fxml.FXML;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.text.Text;
import model.Monde;

public class MondeController {
	
	private Monde monde = new Monde();
	
	@FXML
	private Text infosPays = new Text();
	
	@FXML
	private Text nombreVivants = new Text();
	
	@FXML
	private Text nombreMorts = new Text();
	
	@FXML
	private Pane carte = new Pane();
	
	public void initialisation(MouseEvent e) {
	
		monde.créerListePays();
		infosPays.textProperty().bind(monde.getInfosPays(e));
		nombreVivants.textProperty().bind(monde.getNombreHumains().asString());
		nombreMorts.textProperty().bind(monde.getNombreMorts().asString());
		
	}
}

