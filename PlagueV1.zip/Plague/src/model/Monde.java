package model;

import java.util.ArrayList;

import javafx.beans.property.SimpleLongProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;

public class Monde {

	private Image monde;
	private SimpleStringProperty urlPays = new SimpleStringProperty();
	private ArrayList<Pays> listePays;
	private SimpleLongProperty nombreVivants = new SimpleLongProperty (7550262000L);
	private SimpleLongProperty nombreMorts = new SimpleLongProperty (0);
	
	public Monde (){
		
		this.monde = new Image("/images/terre.png");
		listePays = new ArrayList<Pays>();
		
	}
	
	public SimpleLongProperty getNombreHumains() {
		return nombreVivants;
	}
	
	public SimpleLongProperty getNombreMorts() {
		return nombreMorts;
	}
	
	public SimpleStringProperty getInfosPays(MouseEvent e){
		
		SimpleStringProperty url = new SimpleStringProperty();
		
		// On prend le code couleur du pays sur lequel on clique
		urlPays.setValue(monde.getPixelReader().getColor((int)e.getX(),(int)e.getY()).toString());
		
		// On fait une boucle pour comparer le code couleur des pays et le code couleur reçu
		for (int i = 0; i < listePays.size(); i++){
			
			url.setValue(listePays.get(i).getUrl()); // Prend le code couleur du pays de la liste à l'indice i

			if (url.getValue().equals(urlPays.getValue())) { 
				
				urlPays.setValue(listePays.get(i).getNom() + " :\nClimat : " + listePays.get(i).getClimat() + "\nDensité : "
						+ listePays.get(i).getDensite() + "\nTempérature : " + listePays.get(i).getTemperature() + "\nRichesse : "
						+ listePays.get(i).getRichesse());
				return urlPays;
			} 
		}
		urlPays.setValue("Océan");
		return urlPays;
	}
	
	public void créerListePays() {
		
		listePays.add(new Pays("Afghanistan",0,2,2,1,"0xcc4a85ff"));
		listePays.add(new Pays("Afrique Centrale",0,0,1,2,"0xb9ccb5ff"));
		listePays.add(new Pays("Afrique de l'Est",0,0,1,2,"0x5d0980ff"));
		listePays.add(new Pays("Afrique du Sud",2,2,1,1,"0xa7aaadff"));
		listePays.add(new Pays("Afrique de l'Ouest",0,0,1,2,"0x73b526ff"));
		listePays.add(new Pays("Algérie",0,2,1,1,"0xd17448ff"));
		listePays.add(new Pays("Allemagne",1,1,0,0,"0x66684aff"));
		listePays.add(new Pays("Amérique Centrale",0,0,1,2,"0xbbdc90ff"));
		listePays.add(new Pays("Angola",0,2,1,2,"0xfafbc9ff"));
		listePays.add(new Pays("Arabie Saoudite",2,2,1,1,"0x9a6128ff"));
		listePays.add(new Pays("Argentine",2,0,2,2,"0xd9ac58ff"));
		listePays.add(new Pays("Asie Centrale",0,2,2,1,"0x3ee90fff"));
		listePays.add(new Pays("Asie du Sud Est",0,0,1,0,"0x664fa6ff"));
		listePays.add(new Pays("Australie",1,1,1,1,"0x1c91deff"));
		listePays.add(new Pays("Balkans",2,0,0,0,"0x18c40dff"));
		listePays.add(new Pays("Baltiques",2,0,0,0,"0x97d595ff"));
		listePays.add(new Pays("Bolivie",0,0,2,0,"0xc42b88ff"));
		listePays.add(new Pays("Botswana",0,2,1,2,"0x4ef234ff"));
		listePays.add(new Pays("Brésil",2,0,1,0,"0x34b637ff"));
		listePays.add(new Pays("Canada",1,2,0,2,"0xb25381ff"));
		listePays.add(new Pays("Caraïbes",0,0,1,0,"0x3a7590ff"));
		listePays.add(new Pays("Chine",2,1,2,2,"0x757822ff"));
		listePays.add(new Pays("Colombie",0,0,2,1,"0x772788ff"));
		listePays.add(new Pays("Corée",2,1,2,2,"0x2afa2fff"));
		listePays.add(new Pays("Egypte",0,2,1,1,"0xe4b04cff"));
		listePays.add(new Pays("Europe Centrale",1,2,0,0,"0x0c3a6eff"));
		listePays.add(new Pays("Espagne",1,2,1,1,"0xbc0fcdff"));
		listePays.add(new Pays("Etats-Unis",1,1,2,2,"0xd0f42eff"));
		listePays.add(new Pays("Finlande",1,0,0,0,"0xc53929ff"));
		listePays.add(new Pays("France",1,1,2,2,"0x3e4bcfff"));
		listePays.add(new Pays("Groenland",2,0,0,2,"0xffffffff"));
		listePays.add(new Pays("Islande",1,2,0,2,"0x509957ff"));
		listePays.add(new Pays("Inde",2,0,1,0,"0xd3ecdeff"));
		listePays.add(new Pays("Indonésie",2,0,1,0,"0xef6d16ff"));
		listePays.add(new Pays("Iran",2,2,1,1,"0x37bd8dff"));
		listePays.add(new Pays("Irak",2,2,1,1,"0x5c0d41ff"));
		listePays.add(new Pays("Italie",1,1,2,2,"0xa03505ff"));
		listePays.add(new Pays("Japon",1,1,2,2,"0xfa25e6ff"));
		listePays.add(new Pays("Kazakhstan",0,2,2,1,"0x065b69ff"));
		listePays.add(new Pays("Libye",2,1,1,1,"0xbe1c85ff"));
		listePays.add(new Pays("Madagascar",0,0,2,2,"0x35e677ff"));
		listePays.add(new Pays("Maroc",0,0,1,1,"0x596925ff"));
		listePays.add(new Pays("Mexique",2,1,1,1,"0x5d06aaff"));
		listePays.add(new Pays("Moyen Orient",2,2,1,1,"0x1a8b08ff"));
		listePays.add(new Pays("Norvège",1,1,0,0,"0x6d3bedff"));
		listePays.add(new Pays("Nouvelle Guinée",0,2,1,0,"0xb72887ff"));
		listePays.add(new Pays("Nouvelle Zélande",1,1,2,2,"0x88b094ff"));
		listePays.add(new Pays("Pakistan",0,2,1,1,"0x0366e0ff"));
		listePays.add(new Pays("Pérou",0,0,0,1,"0x118935ff"));
		listePays.add(new Pays("Philippines",0,2,1,0,"0x21a63dff"));
		listePays.add(new Pays("Pologne",2,0,0,0,"0x630768ff"));
		listePays.add(new Pays("Russie",2,0,0,0,"0xd5f861ff"));
		listePays.add(new Pays("Soudan",0,0,1,1,"0x82e2f2ff"));
		listePays.add(new Pays("Suède",1,1,0,0,"0x61b821ff"));
		listePays.add(new Pays("Turquie",2,0,2,2,"0x69090eff"));
		listePays.add(new Pays("Royaume-Uni",1,1,0,0,"0x7187a0ff"));
		listePays.add(new Pays("Ukraine",2,0,0,0,"0xcc6f09ff"));
		listePays.add(new Pays("Zimbabwe",0,2,1,2,"0xf4ef2cff"));
		
	}
}
