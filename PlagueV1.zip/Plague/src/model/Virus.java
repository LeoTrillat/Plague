package model;


public class Virus {
	

}
